"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";
import { LogOut, ChevronLeft } from "lucide-react";
import { registerFCMToken } from "@/lib/firebase-messaging";

export default function Sidebar() {
  const pathname = usePathname();
  const [notificationEnabled, setNotificationEnabled] = useState(false);
  const [notificationLoading, setNotificationLoading] = useState(false);
  const [showNotificationPrompt, setShowNotificationPrompt] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [collapsed, setCollapsed] = useState(true);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const [currentAcademicYear, setCurrentAcademicYear] = useState<any>(null);

  // submenu minh chứng
  const [showProofMenu, setShowProofMenu] = useState(false);
  const [proofMenuPosition, setProofMenuPosition] = useState({
    top: 0,
    left: 0,
  });

  useEffect(() => {
    checkRole();
    checkNotificationStatus();
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    checkMobile();

    window.addEventListener("resize", checkMobile);

    return () =>
      window.removeEventListener("resize", checkMobile);
  }, []);
useEffect(() => {
  async function loadAcademicYear() {
    const { data, error } = await supabase
      .from("academic_years")
      .select("id, name")
      .order("id", { ascending: false })
      .limit(1)
      .single();

    if (error) {
      console.error("Lỗi lấy năm học:", error);
      return;
    }

    setCurrentAcademicYear(data);
  }

  loadAcademicYear();
}, []);
  async function checkRole() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) return;

    const { data } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    setIsAdmin(data?.role === "admin");
  }

  const proofMenus = [
  {
    name: "Đạo đức tốt",
    icon: "/icondaoduc.png",
    href: `/dao-duc?year=${currentAcademicYear?.id || ""}`,
  },
  {
    name: "Học tập tốt",
    icon: "/iconhoctap.png",
    href: `/hoc-tap?year=${currentAcademicYear?.id || ""}`,
  },
  {
    name: "Thể lực tốt",
    icon: "/icontheluc.png",
    href: `/the-luc?year=${currentAcademicYear?.id || ""}`,
  },
  {
    name: "Tình nguyện tốt",
    icon: "/icontinhnguyen.png",
    href: `/tinh-nguyen?year=${currentAcademicYear?.id || ""}`,
  },
  {
    name: "Hội nhập tốt",
    icon: "/iconhoinhap.png",
    href: `/hoi-nhap?year=${currentAcademicYear?.id || ""}`,
  },
  {
    name: "Thành tích khác",
    icon: "/iconuutien.png",
    href: `/uu-tien?year=${currentAcademicYear?.id || ""}`,
  },
];
const proofPaths = [
  "/tieuchi",
  "/dao-duc",
  "/hoc-tap",
  "/the-luc",
  "/tinh-nguyen",
  "/hoi-nhap",
  "/uu-tien",
];
  const menus = [
    {
      name: "Trang chủ",
      icon: "🏠",
      href: "/",
    },
    {
      name: "Quản lí hồ sơ",
      icon: "🗂️",
      href: "/tieuchi",
    },
    {
      name: "Xem Báo cáo",
      icon: "📝",
      href: "/bao-cao",
    },
    {
      name: "Mục tiêu học tập",
      icon: "📊",
      href: "/bang-diem",
    },
    {
      name: "Hoạt động sắp tới",
      icon: "🎯",
      href: "/hoat-dong",
    },
    {
      name: "Thông báo",
      icon: "🔔",
      href: "/thongbaouser",
    },
    {
      name: "Hướng dẫn",
      icon: "📖",
      href: "/huong-dan",
    },

   ...(isAdmin === false
  ? [
      {
        name: "Đổi mật khẩu",
        icon: "🔐",
        href: "/doi-mat-khau",
      },
    ]
  : []),
  ];

  const renderMenuIcon = (icon: string, alt: string) =>
    icon.endsWith(".png") ? (
      <Image
        src={icon}
        width={22}
        height={22}
        alt={alt}
        style={{ display: "inline-block", verticalAlign: "middle", marginRight: 6 }}
      />
    ) : (
      icon
    );

async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = "/introduce";
  }
async function checkNotificationStatus() {
  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) return;

    const { data, error } = await supabase
      .from("notification_tokens")
      .select("id")
      .eq("user_id", user.id)
      .limit(1);

    if (error) {
      console.error("Lỗi kiểm tra notification:", error);
      return;
    }

    const enabled = Array.isArray(data) && data.length > 0;

    setNotificationEnabled(enabled);

    // Đã bật thông báo thì không hỏi nữa
    if (enabled) {
      setShowNotificationPrompt(false);
      return;
    }

    // Kiểm tra người dùng đã lựa chọn trước đó chưa
    const promptKey = `notification_prompt_${user.id}`;
    const alreadyAsked = localStorage.getItem(promptKey);

    if (!alreadyAsked) {
      setShowNotificationPrompt(true);
    }
  } catch (error) {
    console.error("Lỗi kiểm tra trạng thái thông báo:", error);
  }
}
async function handleToggleNotification() {
  if (notificationLoading) return;

  setNotificationLoading(true);

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      alert("❌ Bạn chưa đăng nhập.");
      return;
    }

    // ==========================================
    // ĐANG BẬT → TẮT
    // ==========================================

    if (notificationEnabled) {
      const { error } = await supabase
        .from("notification_tokens")
        .delete()
        .eq("user_id", user.id);

      if (error) {
        console.error(
          "❌ Lỗi xóa notification token:",
          error
        );

        alert("❌ Không thể tắt thông báo.");
        return;
      }

      setNotificationEnabled(false);

      alert("🔕 Đã tắt thông báo.");

      return;
    }

    // ==========================================
    // ĐANG TẮT → BẬT
    // ==========================================

    console.log("🔔 Người dùng yêu cầu bật thông báo");

    const token = await registerFCMToken();

    if (!token) {
      console.log("❌ Không lấy được FCM token");

      setNotificationEnabled(false);

      alert(
        "❌ Không thể bật thông báo.\n\n" +
        "Vui lòng kiểm tra quyền thông báo của trình duyệt/điện thoại."
      );

      return;
    }

    // Token đã được registerFCMToken()
    // lưu vào notification_tokens

    setNotificationEnabled(true);

    alert("🔔 Đã bật thông báo!");

  } catch (error) {
    console.error(
      "❌ LỖI BẬT/TẮT THÔNG BÁO:",
      error
    );

    alert(
      `❌ Lỗi: ${
        error instanceof Error
          ? error.message
          : String(error)
      }`
    );

  } finally {
    setNotificationLoading(false);
  }
}
// Người dùng đồng ý bật thông báo
async function acceptNotificationPrompt() {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) {
    localStorage.setItem(
      `notification_prompt_${user.id}`,
      "accepted"
    );
  }

  setShowNotificationPrompt(false);

  await handleToggleNotification();
}

// Người dùng chọn để sau
async function dismissNotificationPrompt() {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) {
    localStorage.setItem(
      `notification_prompt_${user.id}`,
      "dismissed"
    );
  }

  setShowNotificationPrompt(false);
}

const renderNotificationPrompt = () => {
  if (!showNotificationPrompt) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.55)",
        zIndex: 100000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 380,
          background: "#fff",
          borderRadius: 18,
          padding: 24,
          textAlign: "center",
          boxShadow: "0 15px 40px rgba(0,0,0,0.2)",
        }}
      >
        <div style={{ fontSize: 42, marginBottom: 12 }}>
          🔔
        </div>

        <h3
          style={{
            fontSize: 20,
            fontWeight: 700,
            color: "#1e3a8a",
            marginBottom: 12,
          }}
        >
          Bật thông báo SV5T BMU?
        </h3>

        <p
          style={{
            fontSize: 14,
            color: "#4b5563",
            lineHeight: 1.6,
            marginBottom: 22,
          }}
        >
          Cho phép Hệ thống SV5T BMU thông báo hoạt động mới
          và những cập nhật quan trọng trên thiết bị
        </p>

        <button
          onClick={acceptNotificationPrompt}
          style={{
            width: "100%",
            padding: 13,
            border: "none",
            borderRadius: 10,
            background: "#2563eb",
            color: "#fff",
            fontSize: 15,
            fontWeight: 600,
            cursor: "pointer",
            marginBottom: 10,
          }}
        >
          🔔 Bật thông báo
        </button>

        <button
          onClick={dismissNotificationPrompt}
          style={{
            width: "100%",
            padding: 12,
            border: "1px solid #e5e7eb",
            borderRadius: 10,
            background: "#fff",
            color: "#6b7280",
            fontSize: 14,
            cursor: "pointer",
          }}
        >
          Để sau
        </button>
      </div>
    </div>
  );
};
  // =======================
  // MOBILE
  // =======================

  if (isMobile) {
    return (
      <>
      {renderNotificationPrompt()}
        {mobileMenu && (
          <div
            className="mobile-menu-overlay"
            onClick={() => setMobileMenu(false)}
          >
            <div
              className="mobile-menu"
              onClick={(e) => e.stopPropagation()}
            >
             {menus.map((item) => (
  <Link
    key={item.href}
    href={item.href}
    onClick={() => setMobileMenu(false)}
    className={pathname === item.href ? "active" : ""}
  >
    {renderMenuIcon(item.icon, item.name)} {item.name}
  </Link>
))}

{/* BẬT / TẮT THÔNG BÁO - MOBILE */}
<button
  onClick={handleToggleNotification}
  disabled={notificationLoading}
  style={{
    width: "100%",
    padding: "12px 14px",
    marginTop: 4,
    border: "none",
    borderRadius: 12,
    background: notificationEnabled
      ? "#dcfce7"
      : "#fef3c7",
    color: notificationEnabled
      ? "#166534"
      : "#92400e",
    cursor: notificationLoading
      ? "wait"
      : "pointer",
    display: "flex",
    alignItems: "center",
    gap: 8,
    fontSize: 15,
    fontWeight: 600,
    textAlign: "left",
    opacity: notificationLoading ? 0.7 : 1,
  }}
>
  <span>
    {notificationLoading
      ? "⏳"
      : notificationEnabled
      ? "🔔"
      : "🔕"}
  </span>

  <span>
    {notificationLoading
      ? "Đang xử lý..."
      : notificationEnabled
      ? "Thông báo: Đang bật"
      : "Thông báo: Đang tắt"}
  </span>
</button>

{/* ĐĂNG XUẤT */}
<button
  onClick={handleLogout}
  style={{
    display: "flex",
    alignItems: "center",
    gap: 8,
    background: "#ef4444",
    color: "#fff",
  }}
>
  <LogOut
    size={20}
    style={{ transform: "scaleX(-1)" }}
  />
  <span>Đăng xuất</span>
</button>
            </div>
          </div>
        )}

        <nav className="mobile-bottom-nav">
          <button onClick={() => setMobileMenu(true)}>
            ☰
          </button>

          <Link
            href="/"
            className={pathname === "/" ? "active" : ""}
          >
            <div>🏠</div>
          </Link>

          <Link
            href="/tieuchi"
            className={
              pathname === "/tieuchi" ? "active" : ""
            }
          >
            <div>🗂️</div>
          </Link>

          <Link
            href="/bao-cao"
            className={
              pathname === "/bao-cao" ? "active" : ""
            }
          >
            <div>📝</div>
          </Link>
          <Link
            href="/bang-diem"
            className={
              pathname === "/bang-diem" ? "active" : ""
            }
          >
            <div>📊</div>
          </Link>

          <Link
            href="/hoat-dong"
            className={
              pathname === "/hoat-dong" ? "active" : ""
            }
          >
            <div>🎯</div>
          </Link>

          <Link
            href="/thongbaouser"
            className={
              pathname === "/thongbaouser"
                ? "active"
                : ""
            }
          >
            <div>🔔</div>
          </Link>
        </nav>
      </>
    );
  }

// =======================
// DESKTOP
// =======================

return (
  <>
   {renderNotificationPrompt()}

  <aside
    style={{
      width: collapsed ? "80px" : "280px",
      transition: "0.3s",
      height: "calc(100dvh - 90px)",
      maxHeight: "calc(100dvh - 90px)",
      position: "sticky",
      top: 0,
      background: "#fff",
      borderRight: "1px solid #e5e7eb",
      display: "flex",
      flexDirection: "column",
      overflow: "visible",
      zIndex: 9998,
    }}
  >
    {/* HEADER */}
    <div
      style={{
        padding: "20px 0",
        textAlign: "center",
        flexShrink: 0,
      }}
    >
      {!collapsed && (
        <h2
          style={{
            fontSize: 22,
            fontWeight: 700,
            color: "#1e3a8a",
          }}
        >
          ☰ Menu
        </h2>
      )}
    </div>
    {/* MENU */}
    <div
      style={{
        flex: 1,
        minHeight: 0,
        overflowY: "auto",
        overflowX: "hidden",
        display: "flex",
        flexDirection: "column",
        gap: 8,
        padding: "0 10px",
      }}
    >
      {menus.map((item) => {
        const active = pathname === item.href;
        const proofActive = proofPaths.includes(pathname);

        // ===== MENU MINH CHỨNG =====
        if (item.name === "Quản lí hồ sơ") {
          return (
            <div
              key={item.href}
              style={{ position: "relative" }}
              onMouseEnter={(event) => {
                const rect = event.currentTarget.getBoundingClientRect();
                setProofMenuPosition({
                  top: rect.top,
                  left: rect.right,
                });
                setShowProofMenu(true);
              }}
              onMouseLeave={() => setShowProofMenu(false)}
            >
              <Link
                href="/tieuchi"
                style={{
                  padding: "12px 14px",
                  borderRadius: 12,
                  textDecoration: "none",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  background: proofActive ? "#2563eb" : "transparent",
                  color: proofActive ? "#fff" : "#111",
                  transition: ".25s",
                }}
              >
                <span>
                  {collapsed ? "🗂️" : "🗂️ Quản lí hồ sơ"}
                </span>

                {!collapsed && <span>▶</span>}
              </Link>

              {showProofMenu && (
                <div
                  style={{
                    position: "fixed",
                    left: proofMenuPosition.left,
                    top: proofMenuPosition.top,
                    width: 220,
                    background: "#fff",
                    borderRadius: 14,
                    boxShadow:
                      "0 10px 30px rgba(0,0,0,.18)",
                    padding: 8,
                    zIndex: 99999,
                  }}
                >
{proofMenus.map((sub) => {
  const subActive = pathname === sub.href;

  return (
    <Link
      key={sub.href}
      href={sub.href}
      style={{
        display: "block",
        padding: "10px 14px",
        borderRadius: 10,
        textDecoration: "none",
        background: subActive ? "#2563eb" : "transparent",
        color: subActive ? "#fff" : "#111",
        fontWeight: subActive ? 600 : 400,
        transition: "all .25s ease",
        cursor: "pointer",
      }}
      onMouseEnter={(e) => {
  if (!subActive) {
    e.currentTarget.style.background = "#dbeafe";
    e.currentTarget.style.color = "#1e3a8a";
    e.currentTarget.style.transform = "translateX(6px) translateY(-2px)";
    e.currentTarget.style.boxShadow =
      "0 6px 16px rgba(37,99,235,.18)";
  }
}}

onMouseLeave={(e) => {
  if (!subActive) {
    e.currentTarget.style.background = "transparent";
    e.currentTarget.style.color = "#111";
    e.currentTarget.style.transform = "translateX(0) translateY(0)";
    e.currentTarget.style.boxShadow = "none";
  }
}}
    >
      {renderMenuIcon(sub.icon, sub.name)} {sub.name}
    </Link>
  );
})}
                </div>
              )}
            </div>
          );
        }

        // ===== MENU THƯỜNG =====
        return (
          <Link
            key={item.href}
            href={item.href}
            onMouseEnter={(e) => {
              if (!active) {
                e.currentTarget.style.background =
                  "#bed5f4";
                e.currentTarget.style.color =
                  "#1e3a8a";
                e.currentTarget.style.transform =
                  "translateX(6px)";
              }
            }}
            onMouseLeave={(e) => {
              if (!active) {
                e.currentTarget.style.background =
                  "transparent";
                e.currentTarget.style.color = "#111";
                e.currentTarget.style.transform =
                  "translateX(0)";
              }
            }}
            style={{
              padding: "12px 14px",
              borderRadius: 12,
              textDecoration: "none",
              background: active
                ? "#2563eb"
                : "transparent",
              color: active ? "#fff" : "#111",
              transition: ".25s",
              whiteSpace: "nowrap",
            }}
          >
            {renderMenuIcon(item.icon, item.name)}
            {!collapsed && ` ${item.name}`}
          </Link>
        );
      })}
    </div>
{/* BẬT / TẮT THÔNG BÁO */}
<button
  onClick={handleToggleNotification}
  disabled={notificationLoading}
  style={{
    margin: "8px 10px 0",
    flexShrink: 0,
    padding: "12px 14px",
    borderRadius: 12,
    border: "none",

    background: notificationEnabled
      ? "#dcfce7"
      : "#fef3c7",

    color: notificationEnabled
      ? "#166534"
      : "#92400e",

    cursor: notificationLoading
      ? "wait"
      : "pointer",

    display: "flex",
    alignItems: "center",
    justifyContent: collapsed
      ? "center"
      : "flex-start",

    gap: 8,
    fontSize: 15,
    fontWeight: 600,
    transition: ".25s",
    whiteSpace: "nowrap",
    opacity: notificationLoading ? 0.7 : 1,
  }}
  onMouseEnter={(e) => {
    if (!notificationLoading) {
      e.currentTarget.style.transform =
        "translateX(4px)";
    }
  }}
  onMouseLeave={(e) => {
    e.currentTarget.style.transform =
      "translateX(0)";
  }}
>
  <span>
    {notificationLoading
      ? "⏳"
      : notificationEnabled
      ? "🔔"
      : "🔕"}
  </span>

{!collapsed && (
  <span>
    {notificationLoading
      ? "Đang xử lý..."
      : notificationEnabled
      ? "Thông báo: Đang bật"
      : "Thông báo: Đang tắt"}
  </span>
)}
</button>
    {/* FOOTER */}
    <div
      style={{
        marginTop: "auto",
        padding: 12,
        flexShrink: 0,
      }}
    >
      <button
        onClick={handleLogout}
        style={{
          width: "100%",
          border: "none",
          background: "#ef4444",
          color: "#fff",
          padding: "14px",
          borderRadius: 12,
          cursor: "pointer",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 8,
        }}
      >
        <LogOut
          size={20}
          style={{
            transform: "scaleX(-1)",
          }}
        />
        {!collapsed && "Đăng xuất"}
      </button>
    </div>

    {/* TOGGLE */}
   <button
  onClick={() => setCollapsed(!collapsed)}
  style={{
    position: "absolute",
    right: -15,
    top: "50%",
    transform: "translateY(-50%)",
    width: 34,
    height: 34,
    borderRadius: "50%",
    border: "2px solid #fff",
    background: "#374151",
    color: "#fff",
    cursor: "pointer",
    zIndex: 10001,
    boxShadow: "0 2px 8px rgba(0, 0, 0, 0.25)",

    display: "flex",
    justifyContent: "center",
    alignItems: "center",   // <-- thêm 2 dòng này
  }}
>
  <ChevronLeft
    size={18}
    style={{
      transform: collapsed ? "rotate(180deg)" : "rotate(0deg)",
      transition: "0.3s",
    }}
  />
</button>
  </aside>
  </>
);
}