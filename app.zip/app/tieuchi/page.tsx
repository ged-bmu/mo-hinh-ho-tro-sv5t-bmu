"use client";

import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";
import Header from "../components/Header";
import BellUserTemp from "../components/BellUserTemp";
import Spinner from "../components/Spinner";
import CriteriaModal from "../components/CriteriaModal";
import Image from "next/image";
const MAIN_CRITERIA = [
  "dao-duc",
  "hoc-tap",
  "the-luc",
  "tinh-nguyen",
  "hoi-nhap",
];

function calculateCriterionPercentages(
  items: any[],
  evaluations: any[]
) {
  const result: Record<string, number> = {};

  for (const criterion of MAIN_CRITERIA) {
    const criterionItems = items.filter(
      (item) => item.criterion === criterion
    );

    const requiredItems = criterionItems.filter(
      (item) => item.item_type === "required"
    );

    const additionalItems = criterionItems.filter(
      (item) => item.item_type === "additional"
    );

    const getPercent = (itemId: number) => {
      const evaluation = evaluations.find(
        (e) => e.criterion_item_id === itemId
      );

      return Number(evaluation?.completion_percent || 0);
    };

    const requiredScore =
      requiredItems.length > 0
        ? (
            requiredItems.reduce(
              (sum, item) => sum + getPercent(item.id),
              0
            ) / requiredItems.length
          ) * 0.5
        : 0;

    const additionalScore =
      additionalItems.length > 0
        ? Math.max(
            ...additionalItems.map((item) =>
              getPercent(item.id)
            )
          ) * 0.5
        : 0;

    result[criterion] = requiredScore + additionalScore;
  }

  return result;
}
export default function TieuChiPage() {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [tab, setTab] = useState("proof");
  const [showCriteria, setShowCriteria] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [hoverSubmit, setHoverSubmit] = useState(false);
  const [submissionOpen, setSubmissionOpen] = useState(true);
  const [academicYears, setAcademicYears] = useState<any[]>([]);
  const [currentAcademicYear, setCurrentAcademicYear] = useState<any>(null); 
  const [criteriaResults, setCriteriaResults] = useState<any>(null);
  const [criterionPercentages, setCriterionPercentages] = useState<Record<string, number>>({});
  const [totalProfilePercent, setTotalProfilePercent] = useState(0);
useEffect(() => {
  loadProfile();
  loadAcademicYears();

  const checkMobile = () => {
    setIsMobile(window.innerWidth <= 768);
  };

  checkMobile();
  window.addEventListener("resize", checkMobile);

  return () => window.removeEventListener("resize", checkMobile);
}, []);

useEffect(() => {
  if (!currentAcademicYear) return;

  loadYearProfile(currentAcademicYear.id);
}, [currentAcademicYear]);

useEffect(() => {
  let active = true;

  async function loadCriteriaResults() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!active || !user || !currentAcademicYear?.id) {
      if (active) setCriteriaResults(null);
      return;
    }

    const { data, error } = await supabase
      .from("student_criteria_results")
      .select("dao_duc, hoc_tap, the_luc, tinh_nguyen, hoi_nhap")
      .eq("user_id", user.id)
      .eq("academic_year_id", currentAcademicYear.id)
      .maybeSingle();

    if (!active) return;
    if (error) {
      console.error("Lỗi tải kết quả tiêu chí:", error);
      setCriteriaResults(null);
      return;
    }

    setCriteriaResults(data);
  }

  void loadCriteriaResults();
  return () => {
    active = false;
  };
}, [currentAcademicYear?.id]);


useEffect(() => {
  let active = true;

  async function loadCriterionPercentages() {
    if (!currentAcademicYear?.id) {
      setCriterionPercentages({});
      setTotalProfilePercent(0);
      return;
    }

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!active || !user) return;

    const { data: items, error: itemsError } = await supabase
      .from("sv5t_criterion_items")
      .select("id, criterion, item_type")
      .eq("academic_year_id", currentAcademicYear.id);

    if (itemsError) {
      console.error("Lỗi tải nội dung tiêu chí:", itemsError);
      return;
    }

    const { data: evaluations, error: evaluationsError } =
      await supabase
        .from("sv5t_student_criterion_evaluations")
        .select("criterion_item_id, completion_percent")
        .eq("user_id", user.id)
        .eq("academic_year_id", currentAcademicYear.id);

    if (evaluationsError) {
      console.error("Lỗi tải kết quả đánh giá:", evaluationsError);
      return;
    }

    if (!active) return;

    const percentages = calculateCriterionPercentages(
      items || [],
      evaluations || []
    );

    const total =
      MAIN_CRITERIA.reduce(
        (sum, criterion) => sum + (percentages[criterion] || 0),
        0
      ) / 5;

    setCriterionPercentages(percentages);
    setTotalProfilePercent(total);
  }

  void loadCriterionPercentages();

  return () => {
    active = false;
  };
}, [currentAcademicYear?.id]);

function hasPassedCriterion(field: string) {
  const resultField: Record<string, string> = {
    "dao-duc": "dao_duc",
    "hoc-tap": "hoc_tap",
    "the-luc": "the_luc",
    "tinh-nguyen": "tinh_nguyen",
    "hoi-nhap": "hoi_nhap",
  };

  return criteriaResults?.[resultField[field]] === true;
}


async function loadAcademicYears() {
  const { data, error } = await supabase
    .from("academic_years")
    .select("id, name, is_current, submission_open")
    .order("id", { ascending: false });

  if (error) {
    console.error("Lỗi lấy năm học:", error);
    return;
  }

  setAcademicYears(data || []);

  const current = data?.find((year) => year.is_current);

  if (current) {
    setCurrentAcademicYear(current);
    setSubmissionOpen(current.submission_open);
  }
}

async function loadProfile() {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return;

  const { data } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  setProfile(data);
  setLoading(false);
}
  async function loadYearProfile(yearId: number) {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return;

  const { data: yearProfile, error: yearProfileError } = await supabase
    .from("student_year_profiles")
    .select("is_submitted, submitted_at, trang_thai")
    .eq("user_id", user.id)
    .eq("academic_year_id", yearId)
    .maybeSingle();

  if (yearProfileError) {
    console.error(
      "Lỗi lấy trạng thái hồ sơ theo năm:",
      yearProfileError
    );
    return;
  }

  setProfile((prev: any) => ({
    ...prev,
    is_submitted: yearProfile?.is_submitted ?? false,
    submitted_at: yearProfile?.submitted_at ?? null,
    trang_thai: yearProfile?.trang_thai ?? null,
  }));
}
async function submitProfile() {
  if (!profile?.id) return;

  // Kiểm tra ảnh thẻ 3x4 trước khi nộp hồ sơ
  if (!profile.avatar || !profile.avatar.trim()) {
    alert("Vui lòng tải ảnh thẻ tại mục báo cáo trước khi nộp hồ sơ");
    return;
  }

// KIỂM TRA TRẠNG THÁI NHẬN HỒ SƠ THEO NĂM HỌC
if (!currentAcademicYear?.id) {
  alert("Chưa xác định được năm học.");
  return;
}

const { data: yearSetting, error: settingError } = await supabase
  .from("academic_years")
  .select("submission_open")
  .eq("id", currentAcademicYear.id)
  .single();

if (settingError || !yearSetting) {
  console.error("Lỗi kiểm tra trạng thái nhận hồ sơ:", settingError);
  alert("Không thể kiểm tra trạng thái nhận hồ sơ.");
  return;
}

setSubmissionOpen(yearSetting.submission_open);

if (!yearSetting.submission_open) {
  alert("Hồ sơ đã hết hạn gửi. Hiện tại hệ thống không còn nhận hồ sơ.");
  return;
}

  // Nếu đang ở trạng thái đã nộp → cho phép chỉnh sửa
  const newSubmittedState = !profile.is_submitted;

  const submittedAt = newSubmittedState
    ? new Date().toISOString()
    : null;

if (!currentAcademicYear) {
  alert("Chưa xác định được năm học.");
  return;
}

const { error } = await supabase
  .from("student_year_profiles")
  .upsert(
    {
      user_id: profile.id,
      academic_year_id: currentAcademicYear.id,
      is_submitted: newSubmittedState,
      submitted_at: submittedAt,
      trang_thai: newSubmittedState
        ? "chua_danh_gia"
        : profile.trang_thai,
    },
    {
      onConflict: "user_id,academic_year_id",
    }
  );

  if (error) {
    console.error(error);
    alert("Không thể cập nhật trạng thái hồ sơ.");
    return;
  }

setProfile((prev: any) => ({
  ...prev,
  is_submitted: newSubmittedState,
  submitted_at: submittedAt,
  ...(newSubmittedState && {
    trang_thai: "chua_danh_gia",
  }),
}));
}
  const folders = [
  {
  name: "Đạo đức tốt",
  icon: "/icondaoduc.png",
  link: "/dao-duc",
  field: "dao-duc",
  color: "#FFE3C1", 
},
{
  name: "Học tập tốt",
  icon: "/iconhoctap.png",
  link: "/hoc-tap",
  field: "hoc-tap",
  color: "#ffdff2",
},
{
  name: "Thể lực tốt",
  icon: "/icontheluc.png",
  link: "/the-luc",
  field: "the-luc",
  color: "#e8ffd2",
},
{
  name: "Tình nguyện tốt",
  icon: "/icontinhnguyen.png",
  link: "/tinh-nguyen",
  field: "tinh-nguyen",
  color: "#FFF0EF",
},
{
  name: "Hội nhập tốt",
  icon: "/iconhoinhap.png",
  link: "/hoi-nhap",
  field: "hoi-nhap",
  color: "#F1EAFF", // Xanh ngọc pastel
},
{
  name: "Thành tích khác",
  icon: "/iconuutien.png",
  link: "/uu-tien",
  field: "uu-tien",
  color: "#FFFCE0", // Tím pastel
},
  ];

  if (loading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Spinner />
      </div>
    );
  }
const percent = totalProfilePercent;
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
      }}
    >
 <Header
  tab={tab}
  setTab={setTab}
  openCriteria={() => setShowCriteria(true)}
  openProfile={() => setShowProfile(true)}
/>
  
      <div
        style={{
          position: "fixed",
          top: 90,
          right: 20,
          zIndex: 9999,
        }}
      >
        <BellUserTemp />
      </div>

      <div
        style={{
          display: "flex",
          flex: 1,
        }}
      >
        <Sidebar />

        <main
  style={{
  flex: 1,
  background: "#d6f5ff",
  padding: isMobile ? "16px" : "30px",
  paddingBottom: isMobile ? "90px" : "30px",
  overflowX: "hidden",
}}
>    
          <div
            style={{
              width: "100%",
              maxWidth: isMobile ? "100%" : "900px",
              margin: "0 auto",
            }}
          >

<div
  style={{
  background: "white",
  borderRadius: "16px",
  padding: isMobile ? "12px" : "16px 20px",
  marginBottom: isMobile ? "20px" : "30px",
  boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
}}
>
<div
  style={{
    display: "flex",
    flexDirection: isMobile ? "column" : "row",
    alignItems: isMobile ? "stretch" : "center",
    justifyContent: "space-between",
    gap: isMobile ? "12px" : "20px",
  }}
>
  {/* Nội dung tiến độ */}
  <div
    style={{
      flex: 1,
      minWidth: 0,
    }}
  >
   <h2
  style={{
    margin: 0,
    fontSize: isMobile ? "16px" : "20px",
    lineHeight: "1.25",
    fontWeight: 700,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  }}
>
  Tiến độ Sinh viên 5 Tốt Cấp Trường
</h2>

    <p
      style={{
        margin: "8px 0 10px",
        color: "#64748b",
      }}
    >
      Bạn đã hoàn thành <b>{Math.round(totalProfilePercent)}%</b> tổng hồ sơ.
    </p>

    <div
      style={{
        width: "100%",
        height: "8px",
        background: "#e5e7eb",
        borderRadius: "999px",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          width: `${percent}%`,
          height: "100%",
          background: "linear-gradient(90deg, #2563eb, #60a5fa)",
          transition: "width .4s ease",
          borderRadius: "999px",
        }}
      />
    </div>
  </div>

  {/* Hai nút */}
  <div
    style={{
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "flex-end",
      gap: "10px",
      flexShrink: 0,
    }}
  >
<select
  value={currentAcademicYear?.id || ""}
  onChange={(e) => {
  const selected = academicYears.find(
    (year) => year.id === Number(e.target.value)
  );

  if (!selected) return;

  setCurrentAcademicYear(selected);
  setSubmissionOpen(selected.submission_open);
}}
  style={{
    background: "#fff",
    color: "#2563eb",
    border: "2px solid #2563eb",
    padding: isMobile ? "10px 12px" : "11px 16px",
    borderRadius: "12px",
    fontWeight: 600,
    fontSize: "14px",
    height: isMobile ? "42px" : "44px",
    boxSizing: "border-box",
    cursor: "pointer",
    outline: "none",
  }}
>
  {academicYears.map((year) => (
    <option key={year.id} value={year.id}>
      {year.name}
    </option>
  ))}
</select>

    {/* Gửi báo cáo */}
{/* Gửi báo cáo */}
<div
  style={{
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "5px",
  }}
>
  <button
    type="button"
    onClick={() => {
      if (!submissionOpen) {
        alert(
          "Hồ sơ đã hết hạn gửi. Hiện tại hệ thống không còn nhận hồ sơ."
        );
        return;
      }

      submitProfile();
    }}
    onMouseEnter={(e) => {
      if (!submissionOpen) return;

      setHoverSubmit(true);

      e.currentTarget.style.transform = "translateY(-3px) scale(1.03)";
      e.currentTarget.style.background = profile?.is_submitted
        ? "#15803d"
        : "#1d4ed8";
      e.currentTarget.style.boxShadow = profile?.is_submitted
        ? "0 6px 16px rgba(22, 163, 74, 0.25)"
        : "0 6px 16px rgba(37, 99, 235, 0.25)";
    }}
    onMouseLeave={(e) => {
      if (!submissionOpen) return;

      setHoverSubmit(false);

      e.currentTarget.style.transform = "translateY(0) scale(1)";
      e.currentTarget.style.background = profile?.is_submitted
        ? "#16a34a"
        : "#2563eb";
      e.currentTarget.style.boxShadow = "none";
    }}
    style={{
      background: !submissionOpen
        ? "#94a3b8"
        : profile?.is_submitted
          ? "#16a34a"
          : "#2563eb",

      color: "#fff",

      padding: isMobile
        ? "10px 12px"
        : "11px 16px",

      border: "none",
      borderRadius: "12px",

      fontWeight: 600,
      fontSize: "14px",

      display: "flex",
      justifyContent: "center",
      alignItems: "center",

      height: isMobile
        ? "42px"
        : "44px",

      boxSizing: "border-box",

      cursor: !submissionOpen
        ? "not-allowed"
        : "pointer",

      transition: "all .25s ease",
      whiteSpace: "nowrap",

      opacity: !submissionOpen
        ? 0.8
        : 1,
    }}
  >
    {!submissionOpen
      ? "⛔ Đã hết hạn"
      : profile?.is_submitted
        ? hoverSubmit
          ? (
            <>
              <Image
                src="/iconchinhsua.png"
                width={20}
                height={20}
                alt="Chỉnh sửa"
                style={{
                  display: "inline-block",
                  verticalAlign: "middle",
                  marginRight: 4,
                }}
              />
              Chỉnh sửa
            </>
          )
          : "Đã nộp hồ sơ"
        : "Gửi hồ sơ"}
  </button>

  {/* Dòng chữ bên dưới */}
  {profile?.is_submitted && (
    <span
      style={{
        fontSize: isMobile ? "10px" : "11px",
        color: "#dc2626",
        fontWeight: 500,
        lineHeight: "14px",
        whiteSpace: "nowrap",
      }}
    >
      {submissionOpen
        ? "Nhấn để chỉnh sửa hồ sơ"
        : "Đã hết hạn nộp hồ sơ"}
    </span>
  )}
</div>
  </div>
</div>
</div>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: isMobile
                  ? "1fr"
                  : "repeat(auto-fit, minmax(250px, 1fr))",
                gap: "20px",
              }}
            >
              {folders.map((folder) => (
                <a
                  key={folder.name}
                  href={`${folder.link}?year=${currentAcademicYear?.id || ""}`}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-6px)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                  }}
                  style={{
  transition: "all .25s ease",
  cursor: "pointer",
  background: folder.color,
  padding: "25px",
  borderRadius: "18px",
  textDecoration: "none",
  color: "#111",
  boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
}}
                >
                <div
  style={{
    display: "flex",
    alignItems: "flex-start",
    gap: "8px",
    marginBottom: "14px",
  }}
>
{/* Icon */}
<div
  style={{
    width: "38px",
    height: "38px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  }}
>
  {/* icon ở đây */}

    <Image
      src={folder.icon}
      width={32}
      height={32}
      alt={folder.name}
      style={{
        objectFit: "contain",
      }}
    />
  </div>

  {/* Tên tiêu chí + trạng thái */}
  <div
    style={{
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      gap: "5px",
    }}
  >
    {/* Tên tiêu chí */}
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        minHeight: "38px",
        padding: "0 13px",
        borderRadius: "999px",
        background: "#ffffff",
        border: "2px solid #1667b1",
        color: "#1667b1",
        fontSize: isMobile ? "14px" : "16px",
        fontWeight: 800,
        whiteSpace: "nowrap",
        boxSizing: "border-box",
      }}
    >
      {folder.name.toUpperCase()}
    </div>

    {/* Trạng thái Đạt / Chưa đạt */}
    {folder.name !== "Thành tích khác" && (
      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          padding: "6px 12px",
          borderRadius: "999px",
          background: hasPassedCriterion(folder.field)
            ? "#dcfce7"
            : "#f3f4f6",
          color: hasPassedCriterion(folder.field)
            ? "#166534"
            : "#f36060",
          fontWeight: 600,
          lineHeight: "1",
          fontSize: isMobile ? "14px" : "14px",
          marginTop: "6px",
        }}
      >
        {hasPassedCriterion(folder.field) ? "Đạt" : "Chưa đạt"}
      </div>
    )}
  </div>
</div>
                  {folder.field !== "uu-tien" && (
  <div style={{ marginTop: "12px" }}>
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: "6px",
        fontSize: "13px",
        color: "#475569",
        fontWeight: 600,
      }}
    >
      <span>Mức độ hoàn thành</span>
      <span>
        {Math.round(
          criterionPercentages[folder.field] || 0
        )}%
      </span>
    </div>

    <div
      style={{
        width: "100%",
        height: "8px",
        background: "rgba(255,255,255,0.8)",
        borderRadius: "999px",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          width: `${
            criterionPercentages[folder.field] || 0
          }%`,
          height: "100%",
          background: "linear-gradient(90deg, #2563eb, #60a5fa)",
          borderRadius: "999px",
          transition: "width .4s ease",
        }}
      />
    </div>
  </div>
)}

{folder.field === "uu-tien" && (
  <p
    style={{
      color: "#666",
      marginTop: "8px",
      fontSize: "14px",
    }}
  >
    Nhấn để xem và quản lý minh chứng
  </p>
)}
                </a>
              ))}
            </div>
                  <div
  style={{
    marginTop: "25px",
    background:  "white",
    borderRadius: "16px",
    padding: "25px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  }}
>
  <h2
  style={{
    marginTop: 0,
    marginBottom: "15px",
    fontSize: "16px",
  }}
>
  📝 Nhận xét hồ sơ

  {profile?.nhan_xet &&
    profile.nhan_xet.trim() !== "" &&
    profile?.ngay_nhan_xet && (
      <span
        style={{
          marginLeft: "10px",
          fontSize: "14px",
          fontStyle: "italic",
          color: "#64748b",
          fontWeight: "400",
        }}
      >
        (cập nhật{" "}
        {new Date(
          profile.ngay_nhan_xet
        ).toLocaleString("vi-VN")}
        )
      </span>
    )}
</h2>

  <div
    style={{
      background: "#f8fafc",
      borderRadius: "12px",
      padding: "20px",
      minHeight: "150px",
      whiteSpace: "pre-wrap",
      lineHeight: "1.8",
      color: "#000000",
    }}
  >
    <i>{profile?.nhan_xet || "Chưa có nhận xét"}</i>
  </div>
</div>
          </div>
        </main>
      </div>
    {showCriteria && (
      <CriteriaModal
        onClose={() => setShowCriteria(false)}
      />
    )}
      <Footer />
    </div>
  );
}
