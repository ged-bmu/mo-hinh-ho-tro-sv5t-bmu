"use client";

import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";
import { authFetch as fetch } from "@/lib/auth-fetch";
import Sidebar from "../components/Sidebar";
import CriteriaModal from "../components/CriteriaModal";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Spinner from "../components/Spinner";
import { FaFilePdf } from "react-icons/fa";
import AvatarEditor from "react-avatar-editor";
import { useRef } from "react";
import Image from "next/image";

export default function BaoCaoPage() {
  const [isMobile, setIsMobile] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [avatarMenu, setAvatarMenu] = useState(false);
  const [previewAvatar, setPreviewAvatar] = useState(false);
  const avatarRef = useRef<HTMLDivElement>(null);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [showCrop, setShowCrop] = useState(false);
  const [scale, setScale] = useState(1.2);
  const editorRef = useRef<any>(null);

  useEffect(() => {
  function handleClickOutside(event: MouseEvent) {
    if (
      avatarRef.current &&
      !avatarRef.current.contains(event.target as Node)
    ) {
      setAvatarMenu(false);
    }
  }

  document.addEventListener("mousedown", handleClickOutside);

  return () => {
    document.removeEventListener(
      "mousedown",
      handleClickOutside
    );
  };
}, []);

useEffect(() => {
  const checkMobile = () => {
    setIsMobile(window.innerWidth <= 768);
  };

  checkMobile();

  window.addEventListener("resize", checkMobile);

  return () => window.removeEventListener("resize", checkMobile);
}, []);
  const [profile, setProfile] = useState<any>(null);
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [showCriteria, setShowCriteria] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);
const [editHoTen, setEditHoTen] = useState("");
const [editLop, setEditLop] = useState("");
const [editGioiTinh, setEditGioiTinh] = useState("");
const [editNamSinh, setEditNamSinh] = useState("");
const [editDanToc, setEditDanToc] = useState("");
const [editChucVuDoanHoi, setEditChucVuDoanHoi] = useState("");
const [savingProfile, setSavingProfile] = useState(false);
  const [tab, setTab] = useState("proof");
  const [currentAcademicYear, setCurrentAcademicYear] = useState<any>(null);
  const [academicYears, setAcademicYears] = useState<any[]>([]);

  const criteriaList = [
    { key: "dao-duc", title: "Đạo đức tốt" },
    { key: "hoc-tap", title: "Học tập tốt" },
    { key: "the-luc", title: "Thể lực tốt" },
    { key: "tinh-nguyen", title: "Tình nguyện tốt" },
    { key: "hoi-nhap", title: "Hội nhập tốt" },
    { key: "uu-tien", title: "Thành tích khác" },
  ];

  // =========================
  // INIT
  // =========================

  useEffect(() => {
    init();
  }, []);

async function init() {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    setLoading(false);
    return;
  }

  // Lấy năm học mặc định / năm học mới nhất
  const { data: academicYear, error: yearError } = await supabase
    .from("academic_years")
    .select("id, name")
    .order("id", { ascending: false })
    .limit(1)
    .single();

  if (yearError || !academicYear) {
    console.error("Lỗi lấy năm học mặc định:", yearError);
    setLoading(false);
    return;
  }

  setCurrentAcademicYear(academicYear);

  await Promise.all([
  loadProfile(user.id),
  loadReports(user.id, academicYear.id),
  loadAcademicYears(),
]);

  setLoading(false);
}
async function loadAcademicYears() {
  const { data, error } = await supabase
    .from("academic_years")
    .select("id, name")
    .order("id", { ascending: false });

  if (error) {
    console.error("Lỗi lấy danh sách năm học:", error);
    return;
  }

  setAcademicYears(data || []);
}
  // =========================
  // PROFILE
  // =========================
async function handleAvatarUpload(
  e: React.ChangeEvent<HTMLInputElement>
) {
  const file = e.target.files?.[0];

  if (!file || !profile) return;

  const ext = file.name.split(".").pop();
  const fileName = `${profile.id}.${ext}`;

  const { error } = await supabase.storage
    .from("avatars")
    .upload(fileName, file, {
      upsert: true,
    });

  if (error) {
    console.error("Lỗi upload ảnh đại diện:", error);
    alert(error.message);
    return;
  }

  const { data } = supabase.storage
    .from("avatars")
    .getPublicUrl(fileName);

  const avatar = `${data.publicUrl}?v=${Date.now()}`;

  const { error: updateError } = await supabase
    .from("profiles")
    .update({ avatar })
    .eq("id", profile.id)
    .select();

  if (updateError) {
    console.error("Lỗi cập nhật avatar:", updateError);
    alert(updateError.message);
    return;
  }

  await loadProfile(profile.id);
}
  async function loadProfile(userId: string) {
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();

    if (data) {
      setProfile(data);
    }
  }
  function getStudentYear(lop: string) {
  if (!lop) return "";

  // Lấy 2 chữ số đầu tiên của mã lớp, ví dụ 22DA1 → 22
  const match = lop.match(/(?:^|\D)(\d{2})(?=[A-Z])/i);

  if (!match) return "";

  const admissionYear = 2000 + Number(match[1]);
  const now = new Date();

  // Năm học bắt đầu từ ngày 01/09
  const academicYearStart =
    now.getMonth() >= 8
      ? now.getFullYear()
      : now.getFullYear() - 1;

  const studentYear = academicYearStart - admissionYear + 1;

  if (studentYear < 1) return "";

  return studentYear;
}


async function savePersonalInfo() {
  if (!profile) return;

  const hoTen = editHoTen.trim();
  const lop = editLop.trim();
  const namSinh = editNamSinh.trim();

  if (!hoTen || !lop) {
    alert("Vui lòng nhập đầy đủ họ tên và lớp.");
    return;
  }

  if (namSinh) {
    const year = Number(namSinh);
    if (
      !Number.isInteger(year) ||
      year < 1900 ||
      year > new Date().getFullYear()
    ) {
      alert("Vui lòng nhập năm sinh hợp lệ.");
      return;
    }
  }

  setSavingProfile(true);

  try {
    const { data, error } = await supabase
      .from("profiles")
      .update({
        ho_ten: hoTen,
        lop: lop,
        gioi_tinh: editGioiTinh || null,
        nam_sinh: namSinh ? Number(namSinh) : null,
        dan_toc: editDanToc.trim() || null,
        chuc_vu_doan_hoi: editChucVuDoanHoi.trim() || null,
      })
      .eq("id", profile.id)
      .select("*")
      .single();

    if (error) {
      console.error("Lỗi cập nhật thông tin:", error);
      alert("Không thể cập nhật thông tin. Vui lòng thử lại.");
      return;
    }

    setProfile((prev: any) => ({
      ...prev,
      ...data,
    }));

    setShowEditProfile(false);
    alert("Cập nhật thông tin cá nhân thành công!");
  } catch (error) {
    console.error(error);
    alert("Đã xảy ra lỗi khi cập nhật thông tin.");
  } finally {
    setSavingProfile(false);
  }
}

  // =========================
  // REPORT
  // =========================
async function loadReports(userId: string, academicYearId: number) {
  const { data, error } = await supabase
    .from("reports")
    .select("*")
    .eq("user_id", userId)
    .eq("academic_year_id", academicYearId);

  if (error) {
    console.error("Lỗi lấy báo cáo:", error);
    return;
  }

  setReports(data || []);
}
async function removeAvatar() {
  if (!profile?.avatar) return;

 const fileName = profile.avatar
  .split("/")
  .pop()
  ?.split("?")[0];

await supabase.storage
  .from("avatars")
  .remove([fileName!]);

  await supabase
    .from("profiles")
    .update({ avatar: null })
    .eq("id", profile.id);

  setProfile({
    ...profile,
    avatar: null,
  });
}
  // =========================
  // EXPORT PDF
  // =========================

  async function exportPDF() {
  setExporting(true);

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) return;

    const res = await fetch(`/api/export-pdf/${user.id}`);

    if (!res.ok) {
      alert("Xuất PDF thất bại.");
      return;
    }

    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;

    a.download = `${profile?.lop ?? ""} - ${profile?.ho_ten ?? ""} - Báo cáo thành tích Sinh viên 5 tốt cấp trường.pdf`;

    a.click();

    window.URL.revokeObjectURL(url);

    // Xuất xong → dừng spinner
    setExporting(false);

  } catch (err) {
    console.error(err);
    alert("Có lỗi xảy ra.");
    setExporting(false);
  }
}

  // =========================
  // PRINT
  // =========================

  function printReport() {
    window.print();
  }
  // =========================
  // RETURN
  // =========================

return (
  <div
    style={{
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
    }}
  >
    <Header
  tab={tab}
  setTab={setTab}
  openCriteria={() => setShowCriteria(true)}
  openProfile={() => setShowProfile(true)}
/>

    <div
  style={{
    display: "flex",
    flex: 1,
  }}
>
  <Sidebar />
      <main
  style={{
    flex: 1,
    minWidth: 0,
    background: "#eef3f9",
    padding: isMobile ? "12px" : "30px",
  }}
>
        {loading ? (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              minHeight: "300px",
            }}
          >
            <Spinner />
          </div>
        ) : (
          <div style={{ width: "100%" }}>
           <div
  style={{
    background: "#fff",
    borderRadius: "20px",
    padding: isMobile ? "10px" : "16px",
    overflow: "hidden",
    width: "100%",
    maxWidth: "1600px",
    margin: "0 auto",
    boxShadow: "0 12px 40px rgba(0,0,0,.08)",
    border: "1px solid #e8edf5",
  }}
>
                {/* Thanh chức năng */}

{!isMobile && (
  <div
    style={{
      display: "flex",
      justifyContent: "flex-end",
      marginBottom: "16px",
    }}
  >
     {/* CHỌN NĂM HỌC */}
    <select
      value={currentAcademicYear?.id || ""}
      onChange={async (e) => {
        const yearId = Number(e.target.value);

        const selectedYear = academicYears.find(
          (year) => year.id === yearId
        );

        if (!selectedYear) return;

        setCurrentAcademicYear(selectedYear);

        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (user) {
          await loadReports(user.id, yearId);
        }
      }}
      style={{
        padding: "10px 14px",
        borderRadius: "10px",
        border: "1px solid #cbd5e1",
        background: "#fff",
        color: "#1e3a8a",
        fontWeight: 600,
        fontSize: "14px",
        cursor: "pointer",
        outline: "none",
      }}
    >
      {academicYears.map((year) => (
        <option key={year.id} value={year.id}>
          Năm học {year.name}
        </option>
      ))}
    </select>

    <button
      onClick={exportPDF}
      style={{
        display: "flex",
        alignItems: "center",
        gap: "8px",
        background: "#dc2626",
        color: "#fff",
        border: "none",
        padding: "10px 16px",
        borderRadius: "10px",
        cursor: "pointer",
        fontWeight: 600,
        fontSize: "14px",
      }}
    >
       {exporting ? (
    <Spinner size ={24} />
  ) : (
    <>
      <FaFilePdf size={18} />
      Xuất
      </>
  )}
    </button>
  </div>
)}

                <div
  style={{
    position: "relative",
    textAlign: "center",
    paddingTop: isMobile ? "10px" : 0,
    marginBottom: "18px",
  }}
>
  {/* Ảnh thẻ */}
  <div
    ref={avatarRef}
    style={{
  position: isMobile ? "relative" : "absolute",
  left: isMobile ? "50%" : 60,
  transform: isMobile ? "translateX(-50%)" : "none",
  top: isMobile ? 0 : -60,
  marginBottom: isMobile ? 16 : 0,
      width: isMobile ? 100 : 120,
      height: isMobile ? 133 : 160,
      border: "1px solid #94a3b8",
      borderRadius: 6,
      overflow: "visible",
      background: "#f8fafc",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
<div
  onClick={() => setAvatarMenu(!avatarMenu)}
  style={{
    width: "100%",
    height: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    cursor: "pointer",
  }}
>

  {profile?.avatar ? (
    <img
      src={profile.avatar}
      alt="Ảnh thẻ"
      style={{
        width: "100%",
        height: "100%",
        objectFit: "cover",
      }}
    />
  ) : (
    <span
      style={{
        fontSize: 13,
        color: "#64748b",
        marginBottom: "5px",
      }}
    >
      Ảnh 3×4
      <br/>
      <i>(Nhấn để tải lên)</i>
      </span>
       
  )}
</div>

<input
  id="avatar-upload"
  type="file"
  accept="image/*"
  onChange={(e) => {
  const file = e.target.files?.[0];
  if (!file) return;

  setSelectedImage(file);
  setShowCrop(true);
}}
  style={{ display: "none" }}
/>
{avatarMenu && (
  <div
    style={{
      position: "absolute",
      top: 0,
      left: 120,
      width: 150,
      background: "#fff",
      border: "1px solid #ddd",
      borderRadius: 8,
      boxShadow: "0 5px 15px rgba(0,0,0,.2)",
      zIndex: 99999,
      overflow: "visible",
    }}
  >
    <label
      htmlFor="avatar-upload"
        onMouseEnter={(e) => {
    e.currentTarget.style.background = "#f1f5f9";
  }}
  onMouseLeave={(e) => {
    e.currentTarget.style.background = "transparent";
    e.currentTarget.style.transform = "scale(1)";
  }}
  onMouseDown={(e) => {
    e.currentTarget.style.transform = "scale(0.97)";
  }}
  onMouseUp={(e) => {
    e.currentTarget.style.transform = "scale(1)";
  }}
     style={{
  display: "flex",
  alignItems: "center",
  gap: 10,
  padding: "10px 14px",
  cursor: "pointer",
  fontSize: 15,
  userSelect: "none",
}}
    >
      📤 Tải ảnh lên
    </label>

    {profile?.avatar && (
      <>
        <div
            onClick={() => {
    setPreviewAvatar(true);
    setAvatarMenu(false);
  }}
  onMouseEnter={(e) => {
    e.currentTarget.style.background = "#f1f5f9";
  }}
  onMouseLeave={(e) => {
    e.currentTarget.style.background = "transparent";
    e.currentTarget.style.transform = "scale(1)";
  }}
  onMouseDown={(e) => {
    e.currentTarget.style.transform = "scale(0.97)";
  }}
  onMouseUp={(e) => {
    e.currentTarget.style.transform = "scale(1)";
  }}
          style={{
  display: "flex",
  alignItems: "center",
  gap: 10,
  padding: "10px 14px",
  cursor: "pointer",
  fontSize: 15,
  userSelect: "none",
  whiteSpace: "nowrap",
}}
        >
          <Image src="/iconxem2.png" width={20} height={20} alt="Xem ảnh" />
          Xem ảnh
        </div>

        <div
          onClick={() => {
    removeAvatar();
    setAvatarMenu(false);
  }}
  onMouseEnter={(e) => {
    e.currentTarget.style.background = "#fef2f2";
  }}
  onMouseLeave={(e) => {
    e.currentTarget.style.background = "transparent";
    e.currentTarget.style.transform = "scale(1)";
  }}
  onMouseDown={(e) => {
    e.currentTarget.style.transform = "scale(0.97)";
  }}
  onMouseUp={(e) => {
    e.currentTarget.style.transform = "scale(1)";
  }}
          style={{
  display: "flex",
  alignItems: "center",
  gap: 10,
  padding: "10px 14px",
  cursor: "pointer",
  fontSize: 15,
  userSelect: "none",
}}
        >
          <><Image src="/iconthungrac.png" width={20} height={20} alt="Xóa ảnh" style={{ display: "inline-block", verticalAlign: "middle", marginRight: 4 }} />Xóa ảnh</>
        </div>
      </>
    )}
  </div>
)}
  </div>

  {/* Tiêu đề */}
  <div
    style={{
      fontSize: "24px",
      fontWeight: 700,
      color: "#1e3a8a",
    }}
  >
    BÁO CÁO THÀNH TÍCH
  </div>

  <div
    style={{
      marginTop: 4,
      fontSize: 18,
      fontWeight: 600,
    }}
  >
    ĐỀ NGHỊ CÔNG NHẬN DANH HIỆU SINH VIÊN 5 TỐT CẤP TRƯỜNG
  </div>

  <button
  type="button"
  onClick={() => {
  setEditHoTen(profile?.ho_ten || "");
  setEditLop(profile?.lop || "");
  setEditGioiTinh(profile?.gioi_tinh || "");
  setEditNamSinh(
    profile?.nam_sinh != null ? String(profile.nam_sinh) : ""
  );
  setEditDanToc(profile?.dan_toc || "");
  setEditChucVuDoanHoi(profile?.chuc_vu_doan_hoi || "");
  setShowEditProfile(true);
}}
  style={{
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginTop: 14,
    padding: "10px 16px",
    border: "1px solid #2563eb",
    borderRadius: 10,
    background: "#eff6ff",
    color: "#1d4ed8",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
    maxWidth: "100%",
  }}
>
  Chỉnh sửa thông tin cá nhân
</button>

  <hr
    style={{
      marginTop: 14,
      border: "none",
      borderTop: "2px solid #dbeafe",
    }}
  />
  {isMobile && (
  <div
    style={{
      display: "flex",
      justifyContent: "center",
      marginTop: 16,
      marginBottom: 20,
    }}
  >
    <button
      onClick={exportPDF}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        background: "#dc2626",
        color: "#fff",
        border: "none",
        padding: "10px 18px",
        borderRadius: 10,
        cursor: "pointer",
        fontWeight: 600,
        fontSize: 14,
      }}
    >
      <FaFilePdf size={18} />
      Xuất PDF
    </button>
  </div>
)}
</div>
<div
  style={{
    width: "100%",
    maxWidth: "100%",
    overflowX: "auto",
    overflowY: "hidden",
    WebkitOverflowScrolling: "touch",
  }}
>
               <table
  style={{
    width: "100%",
    minWidth: isMobile ? "900px" : "100%",
    tableLayout: "fixed",
    borderCollapse: "collapse",
  }}
>
                  <thead>
                    <tr>
                      <th
                        style={{
                          width: isMobile ? "250px" : "280px",
                          border:
                            "1px solid #cbd5e1",
                          background:
                            "#eff6ff",
                          padding:
                            "14px 10px",
                          fontWeight: 700,
                          fontSize: 16,
                        }}
                      >
                        Thông tin sinh viên
                      </th>

                      {criteriaList.map(
                        (item) => (
                          <th
                            key={item.key}
                            style={{
                              border:
                                "1px solid #cbd5e1",
                              background:
                                "#eff6ff",
                              padding:
                                "14px 10px",
                              fontWeight: 700,
                              fontSize: 16,
                            }}
                          >
                            {item.title}
                          </th>
                        )
                      )}
                    </tr>
                  </thead>

                  <tbody>
                    <tr>
                      <td
  style={{
    border: "1px solid #cbd5e1",
    padding: "26px",
    verticalAlign: "top",
    lineHeight: "1.6",
    fontSize: "15px",
    whiteSpace: "normal",
    overflowWrap: "anywhere",
    wordBreak: "break-word",
  }}
>
                        <div>
                          <b>Họ và tên:</b> {profile?.ho_ten}
                        </div>

                        <div>
                          <b>MSSV:</b> {profile?.mssv}
                        </div>

                       <div>
  <b>Nam/Nữ:</b> {profile?.gioi_tinh || ""}
</div>

<div>
  <b>Năm sinh:</b> {profile?.nam_sinh || ""}
</div>

<div>
  <b>Dân tộc:</b> {profile?.dan_toc || ""}
</div>

                       <div>
  <b>Sinh viên năm thứ:</b>{" "}
  {profile?.lop
    ? (() => {
        const year = getStudentYear(profile.lop);
        return year ? year : "";
      })()
    : ""}
</div>

                        <div>
                          <b>Lớp:</b> {profile?.lop},
                          Trường Đại học Y Dược
                          Buôn Ma Thuột
                        </div>

                        <div>
  <b>Chức vụ Đoàn - Hội:</b>{" "}
  {profile?.chuc_vu_doan_hoi || ""}
</div>

                        <div>
                          <b>Đảng viên/Đoàn viên:</b>
                        </div>

                        <div>
                          <b>Số điện thoại:</b>
                        </div>

                        <div>
                          <b>Email:</b>{" "}
                          {profile?.email}
                        </div>
                      </td>

                     {criteriaList.map((item) => {
                      
  const report = reports.find(
    (r) => r.criteria === item.key
  );

  return (
<td
  key={item.key}
  style={{
    border: "1px solid #cbd5e1",
    verticalAlign: "top",
    padding: "10px",
    whiteSpace: "normal",
    overflowWrap: "break-word",
    wordBreak: "break-word",
  }}
>
  <div
    style={{
      minHeight: "300px",
      lineHeight: "1.6",
      whiteSpace: "normal",
      overflowWrap: "anywhere",
      wordBreak: "break-word",
    }}
    dangerouslySetInnerHTML={{
      __html: report?.content || "",
    }}
  />
</td>
  );
})}
          </tr>
         </tbody>
        </table>
        </div>
      </div>
    </div>
    )}
  </main>
</div>
  
{showEditProfile && (
  <div
    onClick={(e) => {
      if (e.target === e.currentTarget && !savingProfile) {
        setShowEditProfile(false);
      }
    }}
    style={{
      position: "fixed",
      inset: 0,
      background: "rgba(15, 23, 42, 0.55)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: 100000,
      padding: 16,
      overflowY: "auto",
    }}
  >
    <div
      style={{
        width: "100%",
        maxWidth: 460,
        maxHeight: "90dvh",
        overflowY: "auto",
        background: "#fff",
        borderRadius: 18,
        padding: isMobile ? 20 : 28,
        boxShadow: "0 20px 60px rgba(0,0,0,.25)",
        boxSizing: "border-box",
      }}
    >
      <h2
        style={{
          margin: "0 0 8px",
          color: "#1e3a8a",
          fontSize: 22,
          textAlign: "center",
        }}
      >
        Chỉnh sửa thông tin cá nhân
      </h2>

      <p
        style={{
          margin: "0 0 24px",
          color: "#64748b",
          fontSize: 14,
          textAlign: "center",
          lineHeight: 1.5,
        }}
      >
        Vui lòng kiểm tra thông tin trước khi lưu.
      </p>

      {/* MSSV: chỉ xem, không được sửa */}
      <div style={{ marginBottom: 18 }}>
        <label
          style={{
            display: "block",
            marginBottom: 7,
            fontWeight: 600,
            fontSize: 14,
            color: "#475569",
          }}
        >
          Mã số sinh viên (MSSV)
        </label>

        <input
          type="text"
          value={profile?.mssv || ""}
          readOnly
          disabled
          style={{
            width: "100%",
            boxSizing: "border-box",
            padding: "12px 14px",
            border: "1px solid #e2e8f0",
            borderRadius: 10,
            background: "#f1f5f9",
            color: "#94a3b8",
            fontSize: 15,
            cursor: "not-allowed",
            opacity: 1,
            WebkitTextFillColor: "#94a3b8",
          }}
        />

        <small
          style={{
            display: "block",
            marginTop: 6,
            color: "#94a3b8",
            fontSize: 12,
          }}
        >
          MSSV gắn với tài khoản đăng nhập nên không thể chỉnh sửa.
        </small>
      </div>

      {/* Họ và tên */}
      <div style={{ marginBottom: 18 }}>
        <label
          htmlFor="edit-ho-ten"
          style={{
            display: "block",
            marginBottom: 7,
            fontWeight: 600,
            fontSize: 14,
            color: "#334155",
          }}
        >
          Họ và tên <span style={{ color: "#dc2626" }}>*</span>
        </label>

        <input
          id="edit-ho-ten"
          type="text"
          value={editHoTen}
          onChange={(e) => setEditHoTen(e.target.value)}
          maxLength={150}
          autoComplete="name"
          disabled={savingProfile}
          style={{
            width: "100%",
            boxSizing: "border-box",
            padding: "12px 14px",
            border: "1px solid #cbd5e1",
            borderRadius: 10,
            background: "#fff",
            color: "#0f172a",
            fontSize: 16,
            outlineColor: "#2563eb",
          }}
        />
      </div>

      {/* Lớp */}
      <div style={{ marginBottom: 24 }}>
        <label
          htmlFor="edit-lop"
          style={{
            display: "block",
            marginBottom: 7,
            fontWeight: 600,
            fontSize: 14,
            color: "#334155",
          }}
        >
          Lớp <span style={{ color: "#dc2626" }}>*</span>
        </label>

        <input
          id="edit-lop"
          type="text"
          value={editLop}
          onChange={(e) => setEditLop(e.target.value)}
          maxLength={100}
          disabled={savingProfile}
          placeholder="Ví dụ: Y khoa K25"
          style={{
            width: "100%",
            boxSizing: "border-box",
            padding: "12px 14px",
            border: "1px solid #cbd5e1",
            borderRadius: 10,
            background: "#fff",
            color: "#0f172a",
            fontSize: 16,
            outlineColor: "#2563eb",
          }}
        />
      </div>

{/* Giới tính */}
<div style={{ marginBottom: 18 }}>
  <label
    htmlFor="edit-gioi-tinh"
    style={{
      display: "block",
      marginBottom: 7,
      fontWeight: 600,
      fontSize: 14,
      color: "#334155",
    }}
  >
    Nam/Nữ
  </label>

  <select
    id="edit-gioi-tinh"
    value={editGioiTinh}
    onChange={(e) => setEditGioiTinh(e.target.value)}
    disabled={savingProfile}
    style={{
      width: "100%",
      boxSizing: "border-box",
      padding: "12px 14px",
      border: "1px solid #cbd5e1",
      borderRadius: 10,
      background: "#fff",
      color: "#0f172a",
      fontSize: 16,
    }}
  >
    <option value="">-- Chọn giới tính --</option>
    <option value="Nam">Nam</option>
    <option value="Nữ">Nữ</option>
  </select>
</div>

{/* Năm sinh */}
<div style={{ marginBottom: 18 }}>
  <label
    htmlFor="edit-nam-sinh"
    style={{
      display: "block",
      marginBottom: 7,
      fontWeight: 600,
      fontSize: 14,
      color: "#334155",
    }}
  >
    Năm sinh
  </label>

  <input
    id="edit-nam-sinh"
    type="number"
    value={editNamSinh}
    onChange={(e) => setEditNamSinh(e.target.value)}
    min={1900}
    max={new Date().getFullYear()}
    disabled={savingProfile}
    placeholder="Ví dụ: 2005"
    style={{
      width: "100%",
      boxSizing: "border-box",
      padding: "12px 14px",
      border: "1px solid #cbd5e1",
      borderRadius: 10,
      background: "#fff",
      color: "#0f172a",
      fontSize: 16,
    }}
  />
</div>

{/* Dân tộc */}
<div style={{ marginBottom: 18 }}>
  <label
    htmlFor="edit-dan-toc"
    style={{
      display: "block",
      marginBottom: 7,
      fontWeight: 600,
      fontSize: 14,
      color: "#334155",
    }}
  >
    Dân tộc
  </label>

  <input
    id="edit-dan-toc"
    type="text"
    value={editDanToc}
    onChange={(e) => setEditDanToc(e.target.value)}
    maxLength={100}
    disabled={savingProfile}
    placeholder="Ví dụ: Kinh"
    style={{
      width: "100%",
      boxSizing: "border-box",
      padding: "12px 14px",
      border: "1px solid #cbd5e1",
      borderRadius: 10,
      background: "#fff",
      color: "#0f172a",
      fontSize: 16,
    }}
  />
</div>

{/* Chức vụ Đoàn - Hội */}
<div style={{ marginBottom: 24 }}>
  <label
    htmlFor="edit-chuc-vu-doan-hoi"
    style={{
      display: "block",
      marginBottom: 7,
      fontWeight: 600,
      fontSize: 14,
      color: "#334155",
    }}
  >
    Chức vụ Đoàn - Hội
  </label>

  <input
    id="edit-chuc-vu-doan-hoi"
    type="text"
    value={editChucVuDoanHoi}
    onChange={(e) => setEditChucVuDoanHoi(e.target.value)}
    maxLength={200}
    disabled={savingProfile}
    placeholder="Ví dụ: Bí thư Chi đoàn (không bắt buộc)"
    style={{
      width: "100%",
      boxSizing: "border-box",
      padding: "12px 14px",
      border: "1px solid #cbd5e1",
      borderRadius: 10,
      background: "#fff",
      color: "#0f172a",
      fontSize: 16,
    }}
  />
</div>

      {/* Nút thao tác */}
      <div
        style={{
          display: "flex",
          flexDirection: isMobile ? "column-reverse" : "row",
          justifyContent: "flex-end",
          gap: 10,
        }}
      >
        <button
          type="button"
          disabled={savingProfile}
          onClick={() => setShowEditProfile(false)}
          style={{
            padding: "12px 18px",
            border: "1px solid #cbd5e1",
            borderRadius: 10,
            background: "#fff",
            color: "#475569",
            fontSize: 14,
            fontWeight: 600,
            cursor: savingProfile ? "not-allowed" : "pointer",
          }}
        >
          Hủy
        </button>

        <button
          type="button"
          disabled={savingProfile}
          onClick={savePersonalInfo}
          style={{
            padding: "12px 18px",
            border: "none",
            borderRadius: 10,
            background: savingProfile ? "#93c5fd" : "#2563eb",
            color: "#fff",
            fontSize: 14,
            fontWeight: 600,
            cursor: savingProfile ? "not-allowed" : "pointer",
          }}
        >
          {savingProfile ? "Đang lưu..." : "Lưu thay đổi"}
        </button>
      </div>
    </div>
  </div>
)}

    {showCriteria && (
      <CriteriaModal
        onClose={() => setShowCriteria(false)}
      />
    )}
{previewAvatar && (
  <div
    onClick={() => setPreviewAvatar(false)}
    style={{
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,0,.7)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: 9999,
    }}
  >
    <img
      src={profile.avatar}
      style={{
        maxWidth: "90%",
        maxHeight: "90%",
        borderRadius: 10,
      }}
    />
  </div>
)}
{showCrop && selectedImage && (
  <div
    style={{
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,0,.65)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: 99999,
    }}
  >
    <div
      style={{
        width: 430,
        background: "#fff",
        borderRadius: 16,
        padding: 24,
        boxShadow: "0 20px 60px rgba(0,0,0,.25)",
      }}
    >
      <h3
        style={{
          margin: 0,
          marginBottom: 20,
          textAlign: "center",
          fontSize: 22,
          color: "#1e3a8a",
        }}
      >
        Chỉnh ảnh đại diện
      </h3>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
        }}
      >
        <AvatarEditor
          ref={editorRef}
          image={selectedImage}
          width={300}
          height={400}
          border={20}
          scale={scale}
        />
      </div>

      {/* Zoom */}
      <div
        style={{
          marginTop: 24,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: 8,
            fontWeight: 600,
          }}
        >
          <span>Thu phóng</span>
          <span>{scale.toFixed(1)}x</span>
        </div>

        <input
          type="range"
          min={1}
          max={3}
          step={0.1}
          value={scale}
          onChange={(e) => setScale(Number(e.target.value))}
          style={{
            width: "100%",
            cursor: "pointer",
          }}
        />
      </div>

      {/* Nút */}
      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          gap: 12,
          marginTop: 24,
        }}
      >
        <button
          onClick={() => {
            setShowCrop(false);
            setSelectedImage(null);
          }}
          style={{
            padding: "10px 18px",
            borderRadius: 8,
            border: "1px solid #d1d5db",
            background: "#fff",
            cursor: "pointer",
            fontSize: 15,
          }}
        >
          Hủy
        </button>

        <button
          onClick={async () => {
            const canvas =
              editorRef.current?.getImageScaledToCanvas();

            if (!canvas || !profile) return;

            canvas.toBlob(async (blob: Blob | null) => {
              if (!blob) return;

              const fileName = `${profile.id}.png`;

              const { error } = await supabase.storage
                .from("avatars")
                .upload(fileName, blob, {
                  upsert: true,
                  contentType: "image/png",
                });

              if (error) {
                alert(error.message);
                return;
              }

              const { data } = supabase.storage
                .from("avatars")
                .getPublicUrl(fileName);

              const avatar =
                data.publicUrl + "?t=" + Date.now();

              await supabase
                .from("profiles")
                .update({ avatar })
                .eq("id", profile.id);

              setProfile({
                ...profile,
                avatar,
              });

              setShowCrop(false);
              setSelectedImage(null);
            }, "image/png");
          }}
          style={{
            padding: "10px 20px",
            borderRadius: 8,
            border: "none",
            background: "#2563eb",
            color: "#fff",
            cursor: "pointer",
            fontSize: 15,
            fontWeight: 600,
          }}
        >
          Lưu ảnh
        </button>
      </div>
    </div>
  </div>
)}
    <Footer />
  </div>
);
}
 